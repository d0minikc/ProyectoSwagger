package com.example.dominiclasso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DominiclassoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DominiclassoApplication.class, args);
	}

}

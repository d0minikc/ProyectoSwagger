package com.example.dominiclasso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DominiclassoApplicationTests {

	@Test
	void contextLoads() {
	}

}
